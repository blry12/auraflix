import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://auraflixrepo.000webhostapp.com/auraflix-omega/texts/Omega_Builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://auraflixrepo.000webhostapp.com/auraflix-omega/texts/wizard_notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
