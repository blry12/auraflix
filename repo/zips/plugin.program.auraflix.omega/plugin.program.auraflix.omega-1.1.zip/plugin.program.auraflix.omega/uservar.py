import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'http://auraflix.io/auraflix/texts/Omega_Builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://auraflix.io/auraflix/texts/wizard_notify_omega.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
