import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://auraflixrepo.000webhostapp.com/auraflix/texts/Omega_Builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://auraflixrepo.000webhostapp.com/auraflix/texts/wizard_notify_omega.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
