import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://auraflixrepo.000webhostapp.com/auraflix/texts/Nexus_Builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://auraflixrepo.000webhostapp.com/auraflix/texts/wizard_notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
